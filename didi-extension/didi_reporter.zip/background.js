/**
 * Service worker: recibe datos capturados y los envía al backend.
 * getShopByID -> POST /didi/sede-heartbeat (y cada ~30 s); dailyOrders -> /didi/daily-orders-payload; resto -> /didi/capture.
 */
const HEARTBEAT_INTERVAL_MS = 30000; // 30 segundos
let lastSedePayload = null;
let heartbeatTimer = null;

function getBaseUrl() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({ backendUrl: "https://restaurant.reports.salchimonster.com" }, (o) => {
      resolve(String(o.backendUrl || "https://restaurant.reports.salchimonster.com").replace(/\/$/, ""));
    });
  });
}

async function sendSedeHeartbeat() {
  if (!lastSedePayload) return;
  try {
    const base = await getBaseUrl();
    const res = await fetch(`${base}/didi/sede-heartbeat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(lastSedePayload),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) console.warn("[Didi Capture] sede-heartbeat:", json);
  } catch (err) {
    console.warn("[Didi Capture] sede-heartbeat error:", err);
  }
}

function startHeartbeatInterval() {
  if (heartbeatTimer) return;
  heartbeatTimer = setInterval(sendSedeHeartbeat, HEARTBEAT_INTERVAL_MS);
}

function stopHeartbeatInterval() {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
  lastSedePayload = null;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action !== "sendToBackend" || !msg.type || !msg.data) {
    sendResponse({ ok: false, json: { error: "Invalid message" } });
    return true;
  }

  (async () => {
    try {
      const base = await getBaseUrl();
      const typeLower = String(msg.type).toLowerCase();
      const isDailyOrders = typeLower === "dailyorders";
      const isSedeHeartbeat = typeLower === "getshopbyid";

      if (isSedeHeartbeat) {
        lastSedePayload = msg.data;
        startHeartbeatInterval();
        const res = await fetch(`${base}/didi/sede-heartbeat`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(msg.data),
        });
        const json = await res.json().catch(() => ({}));
        sendResponse({ ok: res.ok, json });
        return;
      }

      const url = isDailyOrders ? `${base}/didi/daily-orders-payload` : `${base}/didi/capture`;
      const body = isDailyOrders ? JSON.stringify(msg.data) : JSON.stringify({ type: msg.type, data: msg.data });

      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body,
      });
      const json = await res.json().catch(() => ({}));
      sendResponse({ ok: res.ok, json });
    } catch (err) {
      sendResponse({ ok: false, json: { error: String(err?.message || err) } });
    }
  })();
  return true;
});
