const statusEl = document.getElementById("status");
const statusText = document.getElementById("statusText");
const backendInput = document.getElementById("backendUrl");
const saveBtn = document.getElementById("save");

function setStatus(message, type = "idle") {
  statusText.textContent = message;
  statusEl.className = "status " + type;
}

saveBtn.addEventListener("click", async () => {
  const url = backendInput.value.trim();
  if (!url) {
    setStatus("Escribe una URL antes de guardar.", "error");
    return;
  }
  try {
    await chrome.storage.sync.set({ backendUrl: url });
    setStatus("URL guardada: " + url, "ok");
  } catch (e) {
    setStatus("Error al guardar: " + (e.message || "desconocido"), "error");
  }
});

async function init() {
  const { backendUrl } = await chrome.storage.sync.get({
    backendUrl: "https://restaurant.reports.salchimonster.com",
  });
  backendInput.value = backendUrl || "";
  backendInput.placeholder = "https://restaurant.reports.salchimonster.com";

  try {
    const { lastCapture } = await chrome.storage.local.get({ lastCapture: null });
    if (lastCapture) {
      const time = lastCapture.at ? new Date(lastCapture.at).toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" }) : "";
      const ok = lastCapture.ok ? "Última captura OK" : "Última captura falló";
      setStatus(time ? `${ok} (${time})` : ok, lastCapture.ok ? "ok" : "error");
    } else {
      setStatus("Extension activa. Las capturas se envían al backend guardado.", "idle");
    }
  } catch {
    setStatus("Extension activa.", "idle");
  }
}

init();
